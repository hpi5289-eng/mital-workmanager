package info.mitalinfosys.workmanager;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
