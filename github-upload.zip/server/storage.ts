import { query, execute } from './db-mssql';
import { nanoid } from 'nanoid';

export interface User {
  id: string;
  username: string;
  password: string;
  role: string;
  name: string;
}

export interface Work {
  id: string;
  date: Date;
  partyName: string;
  workName: string;
  workType: string;
  assignedToId: string | null;
  status: string;
  remark: string | null;
  createdBy: string;
  createdAt: Date;
}

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: { username: string; password: string; role: string; name: string }): Promise<User>;
  updateUser(id: string, updates: Partial<{ username: string; password: string; role: string; name: string }>): Promise<User | undefined>;
  deleteUser(id: string): Promise<void>;
  getAllUsers(): Promise<User[]>;

  getWork(id: string): Promise<Work | undefined>;
  getAllWorks(): Promise<Work[]>;
  createWork(work: Omit<Work, 'id' | 'createdAt'>): Promise<Work>;
  updateWork(id: string, updates: Partial<Omit<Work, 'id' | 'createdAt'>>): Promise<Work | undefined>;
  deleteWork(id: string): Promise<void>;
}

interface DBWork {
  id: string;
  date: Date;
  party_name: string;
  work_name: string;
  work_type: string;
  assigned_to_id: string | null;
  status: string;
  remark: string | null;
  created_by: string;
  created_at: Date;
}

function mapWork(dbWork: DBWork): Work {
  return {
    id: dbWork.id,
    date: dbWork.date,
    partyName: dbWork.party_name,
    workName: dbWork.work_name,
    workType: dbWork.work_type,
    assignedToId: dbWork.assigned_to_id,
    status: dbWork.status,
    remark: dbWork.remark,
    createdBy: dbWork.created_by,
    createdAt: dbWork.created_at,
  };
}

export class MSSQLStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const users = await query<User>('SELECT * FROM users WHERE id = @id', { id });
    return users[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const users = await query<User>('SELECT * FROM users WHERE username = @username', { username });
    return users[0];
  }

  async createUser(user: { username: string; password: string; role: string; name: string }): Promise<User> {
    const id = nanoid();
    await execute(
      `INSERT INTO users (id, username, password, role, name) VALUES (@id, @username, @password, @role, @name)`,
      { id, ...user }
    );
    return { id, ...user };
  }

  async updateUser(id: string, updates: Partial<{ username: string; password: string; role: string; name: string }>): Promise<User | undefined> {
    const setClauses: string[] = [];
    const params: Record<string, any> = { id };

    if (updates.username !== undefined) {
      setClauses.push('username = @username');
      params.username = updates.username;
    }
    if (updates.password !== undefined) {
      setClauses.push('password = @password');
      params.password = updates.password;
    }
    if (updates.role !== undefined) {
      setClauses.push('role = @role');
      params.role = updates.role;
    }
    if (updates.name !== undefined) {
      setClauses.push('name = @name');
      params.name = updates.name;
    }

    if (setClauses.length === 0) return this.getUser(id);

    await execute(`UPDATE users SET ${setClauses.join(', ')} WHERE id = @id`, params);
    return this.getUser(id);
  }

  async deleteUser(id: string): Promise<void> {
    await execute('DELETE FROM users WHERE id = @id', { id });
  }

  async getAllUsers(): Promise<User[]> {
    return await query<User>('SELECT * FROM users');
  }

  async getWork(id: string): Promise<Work | undefined> {
    const works = await query<DBWork>('SELECT * FROM works WHERE id = @id', { id });
    return works[0] ? mapWork(works[0]) : undefined;
  }

  async getAllWorks(): Promise<Work[]> {
    const dbWorks = await query<DBWork>('SELECT * FROM works ORDER BY created_at DESC');
    return dbWorks.map(mapWork);
  }

  async createWork(work: Omit<Work, 'id' | 'createdAt'>): Promise<Work> {
    const id = nanoid();
    const created_at = new Date();
    await execute(
      `INSERT INTO works (id, date, party_name, work_name, work_type, assigned_to_id, status, remark, created_by, created_at) 
       VALUES (@id, @date, @party_name, @work_name, @work_type, @assigned_to_id, @status, @remark, @created_by, @created_at)`,
      { 
        id, 
        date: work.date,
        party_name: work.partyName,
        work_name: work.workName,
        work_type: work.workType,
        assigned_to_id: work.assignedToId,
        status: work.status,
        remark: work.remark,
        created_by: work.createdBy,
        created_at 
      }
    );
    return { id, ...work, createdAt: created_at };
  }

  async updateWork(id: string, updates: Partial<Omit<Work, 'id' | 'createdAt'>>): Promise<Work | undefined> {
    const setClauses: string[] = [];
    const params: Record<string, any> = { id };

    if (updates.date !== undefined) {
      setClauses.push('date = @date');
      params.date = updates.date;
    }
    if (updates.partyName !== undefined) {
      setClauses.push('party_name = @party_name');
      params.party_name = updates.partyName;
    }
    if (updates.workName !== undefined) {
      setClauses.push('work_name = @work_name');
      params.work_name = updates.workName;
    }
    if (updates.workType !== undefined) {
      setClauses.push('work_type = @work_type');
      params.work_type = updates.workType;
    }
    if (updates.assignedToId !== undefined) {
      setClauses.push('assigned_to_id = @assigned_to_id');
      params.assigned_to_id = updates.assignedToId;
    }
    if (updates.status !== undefined) {
      setClauses.push('status = @status');
      params.status = updates.status;
    }
    if (updates.remark !== undefined) {
      setClauses.push('remark = @remark');
      params.remark = updates.remark;
    }
    if (updates.createdBy !== undefined) {
      setClauses.push('created_by = @created_by');
      params.created_by = updates.createdBy;
    }

    if (setClauses.length === 0) return this.getWork(id);

    await execute(`UPDATE works SET ${setClauses.join(', ')} WHERE id = @id`, params);
    return this.getWork(id);
  }

  async deleteWork(id: string): Promise<void> {
    await execute('DELETE FROM works WHERE id = @id', { id });
  }
}

export const storage = new MSSQLStorage();
