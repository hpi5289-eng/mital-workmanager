import sql from 'mssql';

let pool: sql.ConnectionPool | null = null;
let config: sql.config | null = null;

function getConfig(): sql.config {
  if (!config) {
    // Parse server and instance name from MSSQL_SERVER (e.g., "LIVE-95\SQLEXPRESS" or "localhost\SQLEXPRESS")
    const serverParts = (process.env.MSSQL_SERVER || 'localhost').split('\\');
    const serverName = serverParts[0];
    const instanceName = serverParts[1] || undefined;

    config = {
      server: serverName,
      database: process.env.MSSQL_DATABASE!,
      user: process.env.MSSQL_USER!,
      password: process.env.MSSQL_PASSWORD!,
      port: process.env.MSSQL_PORT ? parseInt(process.env.MSSQL_PORT) : undefined,
      options: {
        encrypt: false,
        trustServerCertificate: true,
        enableArithAbort: true,
        instanceName: instanceName,
      },
      connectionTimeout: 30000,
      pool: {
        max: 10,
        min: 0,
        idleTimeoutMillis: 30000,
      },
    };
  }
  return config;
}

export async function getPool(): Promise<sql.ConnectionPool> {
  if (!pool) {
    pool = await new sql.ConnectionPool(getConfig()).connect();
    console.log('Connected to SQL Server');
  }
  return pool;
}

export async function query<T>(queryString: string, params?: Record<string, any>): Promise<T[]> {
  const poolConnection = await getPool();
  const request = poolConnection.request();
  
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      request.input(key, value);
    });
  }
  
  const result = await request.query(queryString);
  return result.recordset as T[];
}

export async function execute(queryString: string, params?: Record<string, any>): Promise<sql.IResult<any>> {
  const poolConnection = await getPool();
  const request = poolConnection.request();
  
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      request.input(key, value);
    });
  }
  
  return await request.query(queryString);
}

export { sql };
