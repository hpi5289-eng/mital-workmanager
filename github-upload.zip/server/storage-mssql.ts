import { query, execute } from './db-mssql';
import { nanoid } from 'nanoid';

export interface User {
  id: string;
  username: string;
  password: string;
  role: string;
  name: string;
}

export interface Work {
  id: string;
  date: Date;
  party_name: string;
  work_name: string;
  work_type: string;
  assigned_to_id: string | null;
  status: string;
  remark: string | null;
  created_by: string;
  created_at: Date;
}

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: Omit<User, 'id'>): Promise<User>;
  updateUser(id: string, updates: Partial<Omit<User, 'id'>>): Promise<User | undefined>;
  deleteUser(id: string): Promise<void>;
  getAllUsers(): Promise<User[]>;

  getWork(id: string): Promise<Work | undefined>;
  getAllWorks(): Promise<Work[]>;
  createWork(work: Omit<Work, 'id' | 'created_at'>): Promise<Work>;
  updateWork(id: string, updates: Partial<Omit<Work, 'id' | 'created_at'>>): Promise<Work | undefined>;
  deleteWork(id: string): Promise<void>;
}

export class MSSQLStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const users = await query<User>('SELECT * FROM users WHERE id = @id', { id });
    return users[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const users = await query<User>('SELECT * FROM users WHERE username = @username', { username });
    return users[0];
  }

  async createUser(user: Omit<User, 'id'>): Promise<User> {
    const id = nanoid();
    await execute(
      `INSERT INTO users (id, username, password, role, name) VALUES (@id, @username, @password, @role, @name)`,
      { id, ...user }
    );
    return { id, ...user };
  }

  async updateUser(id: string, updates: Partial<Omit<User, 'id'>>): Promise<User | undefined> {
    const setClauses: string[] = [];
    const params: Record<string, any> = { id };

    if (updates.username !== undefined) {
      setClauses.push('username = @username');
      params.username = updates.username;
    }
    if (updates.password !== undefined) {
      setClauses.push('password = @password');
      params.password = updates.password;
    }
    if (updates.role !== undefined) {
      setClauses.push('role = @role');
      params.role = updates.role;
    }
    if (updates.name !== undefined) {
      setClauses.push('name = @name');
      params.name = updates.name;
    }

    if (setClauses.length === 0) return this.getUser(id);

    await execute(`UPDATE users SET ${setClauses.join(', ')} WHERE id = @id`, params);
    return this.getUser(id);
  }

  async deleteUser(id: string): Promise<void> {
    await execute('DELETE FROM users WHERE id = @id', { id });
  }

  async getAllUsers(): Promise<User[]> {
    return await query<User>('SELECT * FROM users');
  }

  async getWork(id: string): Promise<Work | undefined> {
    const works = await query<Work>('SELECT * FROM works WHERE id = @id', { id });
    return works[0];
  }

  async getAllWorks(): Promise<Work[]> {
    return await query<Work>('SELECT * FROM works ORDER BY created_at DESC');
  }

  async createWork(work: Omit<Work, 'id' | 'created_at'>): Promise<Work> {
    const id = nanoid();
    const created_at = new Date();
    await execute(
      `INSERT INTO works (id, date, party_name, work_name, work_type, assigned_to_id, status, remark, created_by, created_at) 
       VALUES (@id, @date, @party_name, @work_name, @work_type, @assigned_to_id, @status, @remark, @created_by, @created_at)`,
      { id, ...work, created_at }
    );
    return { id, ...work, created_at };
  }

  async updateWork(id: string, updates: Partial<Omit<Work, 'id' | 'created_at'>>): Promise<Work | undefined> {
    const setClauses: string[] = [];
    const params: Record<string, any> = { id };

    Object.entries(updates).forEach(([key, value]) => {
      if (value !== undefined) {
        setClauses.push(`${key} = @${key}`);
        params[key] = value;
      }
    });

    if (setClauses.length === 0) return this.getWork(id);

    await execute(`UPDATE works SET ${setClauses.join(', ')} WHERE id = @id`, params);
    return this.getWork(id);
  }

  async deleteWork(id: string): Promise<void> {
    await execute('DELETE FROM works WHERE id = @id', { id });
  }
}

export const storage = new MSSQLStorage();
