import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";

const insertUserSchema = z.object({
  username: z.string(),
  password: z.string(),
  role: z.string().default("staff"),
  name: z.string(),
});

const insertWorkSchema = z.object({
  date: z.coerce.date().default(() => new Date()),
  partyName: z.string(),
  workName: z.string(),
  workType: z.string().default("BASIC"),
  assignedToId: z.string().nullable().optional(),
  status: z.string().default("pending"),
  remark: z.string().nullable().optional(),
  createdBy: z.string(),
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // ============ AUTH ============
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      const user = await storage.getUserByUsername(username);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      res.json({ user: { id: user.id, username: user.username, role: user.role, name: user.name } });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  // ============ USERS ============
  app.get("/api/users", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      const safeUsers = users.map(u => ({ id: u.id, username: u.username, role: u.role, name: u.name }));
      res.json(safeUsers);
    } catch (error) {
      console.error("Get users error:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/users", async (req, res) => {
    try {
      const parsed = insertUserSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: "Invalid data", errors: parsed.error.errors });
      }
      const user = await storage.createUser(parsed.data);
      res.json({ id: user.id, username: user.username, role: user.role, name: user.name });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.patch("/api/users/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const user = await storage.updateUser(id, req.body);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json({ id: user.id, username: user.username, role: user.role, name: user.name });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.delete("/api/users/:id", async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteUser(id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // ============ WORKS ============
  app.get("/api/works", async (req, res) => {
    try {
      const works = await storage.getAllWorks();
      res.json(works);
    } catch (error) {
      console.error("Get works error:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  app.post("/api/works", async (req, res) => {
    try {
      const parsed = insertWorkSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: "Invalid data", errors: parsed.error.errors });
      }
      const work = await storage.createWork(parsed.data);
      res.json(work);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.patch("/api/works/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const work = await storage.updateWork(id, req.body);
      if (!work) {
        return res.status(404).json({ message: "Work not found" });
      }
      res.json(work);
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  app.delete("/api/works/:id", async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteWork(id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });

  // ============ SEED ADMIN ============
  app.post("/api/seed-admin", async (req, res) => {
    try {
      const existingAdmin = await storage.getUserByUsername("admin");
      if (existingAdmin) {
        return res.json({ message: "Admin already exists" });
      }
      
      const admin = await storage.createUser({
        username: "admin",
        password: "18401",
        role: "admin",
        name: "Administrator"
      });
      
      res.json({ message: "Admin created", user: { id: admin.id, username: admin.username, role: admin.role, name: admin.name } });
    } catch (error) {
      console.error("Seed admin error:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  return httpServer;
}
