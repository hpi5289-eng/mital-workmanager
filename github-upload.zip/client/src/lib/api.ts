const isCapacitor = typeof window !== 'undefined' && (window as any).Capacitor?.isNativePlatform?.();
const API_BASE = isCapacitor ? "https://web.mitalinfosys.info/api" : "/api";

export interface User {
  id: string;
  username: string;
  role: string;
  name: string;
}

export interface Work {
  id: string;
  date: string;
  partyName: string;
  workName: string;
  workType: string;
  assignedToId?: string | null;
  status: string;
  remark?: string | null;
  createdBy: string;
  createdAt: string;
}

export const api = {
  async login(username: string, password: string): Promise<{ user: User }> {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password }),
    });
    if (!res.ok) throw new Error("Login failed");
    return res.json();
  },

  async getUsers(): Promise<User[]> {
    const res = await fetch(`${API_BASE}/users`);
    if (!res.ok) throw new Error("Failed to fetch users");
    return res.json();
  },

  async createUser(data: { username: string; password: string; role: string; name: string }): Promise<User> {
    const res = await fetch(`${API_BASE}/users`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error("Failed to create user");
    return res.json();
  },

  async updateUser(id: string, data: Partial<{ username: string; password: string; role: string; name: string }>): Promise<User> {
    const res = await fetch(`${API_BASE}/users/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error("Failed to update user");
    return res.json();
  },

  async deleteUser(id: string): Promise<void> {
    const res = await fetch(`${API_BASE}/users/${id}`, { method: "DELETE" });
    if (!res.ok) throw new Error("Failed to delete user");
  },

  async getWorks(): Promise<Work[]> {
    const res = await fetch(`${API_BASE}/works`);
    if (!res.ok) throw new Error("Failed to fetch works");
    return res.json();
  },

  async createWork(data: Omit<Work, "id" | "createdAt">): Promise<Work> {
    const res = await fetch(`${API_BASE}/works`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error("Failed to create work");
    return res.json();
  },

  async updateWork(id: string, data: Partial<Work>): Promise<Work> {
    const res = await fetch(`${API_BASE}/works/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error("Failed to update work");
    return res.json();
  },

  async deleteWork(id: string): Promise<void> {
    const res = await fetch(`${API_BASE}/works/${id}`, { method: "DELETE" });
    if (!res.ok) throw new Error("Failed to delete work");
  },

  async seedAdmin(): Promise<void> {
    await fetch(`${API_BASE}/seed-admin`, { method: "POST" });
  },
};
