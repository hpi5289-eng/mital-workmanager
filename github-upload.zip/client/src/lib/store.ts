import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { api, type User, type Work } from './api';

export type Role = 'admin' | 'staff';
export type WorkType = 'COMPUTER' | 'CCTV' | 'PAYMENT' | 'SERVICE_CENTER' | 'BASIC' | 'PUR_DEALER';
export type WorkStatus = 'pending' | 'done' | 'approval_pending';

export type { User, Work };

interface AppState {
  currentUser: User | null;
  users: User[];
  works: Work[];
  isLoading: boolean;
  
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => void;
  
  fetchUsers: () => Promise<void>;
  addUser: (user: { username: string; password: string; role: string; name: string }) => Promise<void>;
  updateUser: (id: string, updates: Partial<{ username: string; password: string; role: string; name: string }>) => Promise<void>;
  deleteUser: (id: string) => Promise<void>;
  
  fetchWorks: () => Promise<void>;
  addWork: (work: Omit<Work, 'id' | 'createdAt'>) => Promise<void>;
  updateWork: (id: string, updates: Partial<Work>) => Promise<void>;
  deleteWork: (id: string) => Promise<void>;
  
  initializeData: () => Promise<void>;
}

export const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      currentUser: null,
      users: [],
      works: [],
      isLoading: false,

      login: async (username: string, password: string) => {
        try {
          const { user } = await api.login(username, password);
          set({ currentUser: user });
          return true;
        } catch {
          return false;
        }
      },

      logout: () => set({ currentUser: null }),

      fetchUsers: async () => {
        try {
          const users = await api.getUsers();
          set({ users });
        } catch (error) {
          console.error("Failed to fetch users:", error);
        }
      },

      addUser: async (user) => {
        try {
          const newUser = await api.createUser(user);
          set((state) => ({ users: [...state.users, newUser] }));
        } catch (error) {
          console.error("Failed to add user:", error);
        }
      },

      updateUser: async (id, updates) => {
        try {
          const updatedUser = await api.updateUser(id, updates);
          set((state) => ({
            users: state.users.map((u) => (u.id === id ? updatedUser : u)),
          }));
        } catch (error) {
          console.error("Failed to update user:", error);
        }
      },

      deleteUser: async (id) => {
        try {
          await api.deleteUser(id);
          set((state) => ({
            users: state.users.filter((u) => u.id !== id),
          }));
        } catch (error) {
          console.error("Failed to delete user:", error);
        }
      },

      fetchWorks: async () => {
        try {
          const works = await api.getWorks();
          set({ works });
        } catch (error) {
          console.error("Failed to fetch works:", error);
        }
      },

      addWork: async (work) => {
        try {
          const newWork = await api.createWork(work);
          set((state) => ({ works: [newWork, ...state.works] }));
        } catch (error) {
          console.error("Failed to add work:", error);
        }
      },

      updateWork: async (id, updates) => {
        try {
          const updatedWork = await api.updateWork(id, updates);
          set((state) => ({
            works: state.works.map((w) => (w.id === id ? updatedWork : w)),
          }));
        } catch (error) {
          console.error("Failed to update work:", error);
        }
      },

      deleteWork: async (id) => {
        try {
          await api.deleteWork(id);
          set((state) => ({
            works: state.works.filter((w) => w.id !== id),
          }));
        } catch (error) {
          console.error("Failed to delete work:", error);
        }
      },

      initializeData: async () => {
        set({ isLoading: true });
        try {
          await api.seedAdmin();
          await get().fetchUsers();
          await get().fetchWorks();
        } catch (error) {
          console.error("Failed to initialize data:", error);
        }
        set({ isLoading: false });
      },
    }),
    {
      name: 'work-manager-storage',
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({ currentUser: state.currentUser }),
    }
  )
);
