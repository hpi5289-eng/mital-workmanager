import { useState, useEffect } from "react";
import { LayoutShell } from "@/components/layout-shell";
import { useStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Plus, CheckCircle2, AlertCircle, ListTodo, Phone, BookUser, Keyboard, Search } from "lucide-react";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";

export default function StaffDashboard() {
  const { works, addWork, updateWork, currentUser, fetchWorks } = useStore();
  const { toast } = useToast();

  useEffect(() => {
    fetchWorks();
  }, [fetchWorks]);

  const [newWork, setNewWork] = useState({
    partyName: "",
    workName: "",
    workType: "BASIC" as const,
  });
  
  const [remark, setRemark] = useState("");
  const [markingDoneId, setMarkingDoneId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  // Mock data for call logs and contacts
  const mockCallLogs = [
    { name: "Unknown", number: "9123456789", time: "10:30 AM" },
    { name: "Rahul Sharma", number: "9876543210", time: "09:15 AM" },
    { name: "Amit Patel", number: "9988776655", time: "Yesterday" },
  ];

  const mockContacts = [
    { name: "Suresh Mehra", number: "8877665544" },
    { name: "Vikram Singh", number: "7766554433" },
    { name: "Deepak Jha", number: "6655443322" },
  ];

  const myPendingWorks = works.filter(w => 
    w.status === 'pending' && w.assignedToId === currentUser?.id
  );
  
  const myRequests = works.filter(w => 
    w.status === 'approval_pending' && w.createdBy === currentUser?.id
  );
  
  const myDoneWorks = works.filter(w => 
    w.status === 'done' && w.assignedToId === currentUser?.id
  );

  const filteredDone = myDoneWorks.filter(w => {
    const searchLower = searchQuery.toLowerCase();
    const matchesParty = w.partyName.toLowerCase().includes(searchLower);
    const matchesDate = format(new Date(w.date), "dd/MM/yy").includes(searchLower);
    return matchesParty || matchesDate;
  });

  const handleCreateWork = async () => {
    if (!newWork.partyName || !newWork.workName) {
      toast({ variant: "destructive", title: "Missing fields" });
      return;
    }

    await addWork({
      ...newWork,
      date: new Date().toISOString(),
      status: 'approval_pending', 
      createdBy: currentUser?.id || '',
      assignedToId: currentUser?.id 
    });
    
    setNewWork({ partyName: "", workName: "", workType: "BASIC" });
    toast({ title: "Work Request Sent", description: "Waiting for admin approval." });
  };

  const handleMarkDone = async (id: string) => {
    if (!remark) {
      toast({ variant: "destructive", title: "Remark is required" });
      return;
    }
    await updateWork(id, { status: 'done', remark });
    setMarkingDoneId(null);
    setRemark("");
    toast({ title: "Great job! Work completed." });
  };

  const selectParty = (name: string, number?: string) => {
    setNewWork({ ...newWork, partyName: number ? `${name} (${number})` : name });
    toast({ title: "Party Selected", description: name });
  };

  return (
    <LayoutShell title="MITAL_INFOSYS_STAFF_PANEL">
      <div className="mb-6">
        <Dialog>
          <DialogTrigger asChild>
            <Button className="w-full h-12 text-lg shadow-md bg-teal-600 hover:bg-teal-700">
              <Plus className="w-5 h-5 mr-2" /> Add New Work
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Add New Work Entry</DialogTitle>
              <DialogDescription>Add task for approval. Date is auto-set to today.</DialogDescription>
            </DialogHeader>
            <div className="space-y-6 py-4">
              <div className="space-y-4">
                <Label className="text-base font-bold text-teal-700">Select Party Source</Label>
                <Tabs defaultValue="manual" className="w-full">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="manual" className="gap-2">
                      <Keyboard className="w-4 h-4" /> Manual
                    </TabsTrigger>
                    <TabsTrigger value="calllog" className="gap-2">
                      <Phone className="w-4 h-4" /> Call Log
                    </TabsTrigger>
                    <TabsTrigger value="contacts" className="gap-2">
                      <BookUser className="w-4 h-4" /> Contacts
                    </TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="manual" className="pt-4">
                    <div className="space-y-2">
                      <Label>Party Name / Mobile</Label>
                      <Input 
                        placeholder="Type party details..." 
                        value={newWork.partyName}
                        onChange={(e) => setNewWork({...newWork, partyName: e.target.value})}
                      />
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="calllog" className="pt-4">
                    <div className="grid grid-cols-1 gap-2 max-h-48 overflow-y-auto pr-2 border rounded-md p-2">
                      {mockCallLogs.map((log, i) => (
                        <Button 
                          key={i} 
                          variant="outline" 
                          className="justify-between text-left h-auto py-2 px-3 border-teal-100 hover:bg-teal-50"
                          onClick={() => selectParty(log.name, log.number)}
                        >
                          <div className="flex flex-col">
                            <span className="font-semibold">{log.name}</span>
                            <span className="text-xs text-muted-foreground">{log.number}</span>
                          </div>
                          <span className="text-[10px] bg-teal-100 text-teal-800 px-1.5 py-0.5 rounded">{log.time}</span>
                        </Button>
                      ))}
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="contacts" className="pt-4">
                    <div className="grid grid-cols-1 gap-2 max-h-48 overflow-y-auto pr-2 border rounded-md p-2">
                      {mockContacts.map((contact, i) => (
                        <Button 
                          key={i} 
                          variant="outline" 
                          className="justify-between text-left h-auto py-2 px-3 border-teal-100 hover:bg-teal-50"
                          onClick={() => selectParty(contact.name, contact.number)}
                        >
                          <div className="flex flex-col">
                            <span className="font-semibold">{contact.name}</span>
                            <span className="text-xs text-muted-foreground">{contact.number}</span>
                          </div>
                          <BookUser className="w-4 h-4 text-teal-200" />
                        </Button>
                      ))}
                    </div>
                  </TabsContent>
                </Tabs>
              </div>

              <div className="space-y-2">
                <Label>Work Description</Label>
                <Input 
                  placeholder="Details of work..." 
                  value={newWork.workName}
                  onChange={(e) => setNewWork({...newWork, workName: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <Label>Work Type</Label>
                <Select 
                  value={newWork.workType}
                  onValueChange={(val: any) => setNewWork({...newWork, workType: val})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {['COMPUTER', 'CCTV', 'PAYMENT', 'SERVICE_CENTER', 'BASIC', 'PUR_DEALER'].map(t => (
                      <SelectItem key={t} value={t}>{t}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Button onClick={handleCreateWork} className="w-full bg-teal-600 hover:bg-teal-700 font-bold h-12">
                Submit for Approval
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="pending" className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-6">
          <TabsTrigger value="pending">
            <ListTodo className="w-4 h-4 mr-2" /> To-Do ({myPendingWorks.length})
          </TabsTrigger>
          <TabsTrigger value="requests">
             <AlertCircle className="w-4 h-4 mr-2" /> Requests ({myRequests.length})
          </TabsTrigger>
          <TabsTrigger value="done">
            <CheckCircle2 className="w-4 h-4 mr-2" /> Done
          </TabsTrigger>
        </TabsList>

        <TabsContent value="pending" className="space-y-4">
          {myPendingWorks.map(work => (
            <Card key={work.id} className="border-l-4 border-l-teal-500 shadow-sm">
              <div className="p-4 flex flex-col gap-3">
                <div className="flex justify-between items-start">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <Badge variant="outline" className="text-xs bg-teal-50 border-teal-200 text-teal-700 font-bold">URGENT</Badge>
                      <Badge variant="outline" className="text-xs">{work.workType}</Badge>
                      <span className="text-xs text-muted-foreground">{format(new Date(work.date), "dd MMM yyyy")}</span>
                    </div>
                    <h3 className="font-bold text-lg text-teal-900">{work.partyName}</h3>
                    <p className="text-muted-foreground text-sm leading-relaxed">{work.workName}</p>
                  </div>
                </div>

                <Dialog open={markingDoneId === work.id} onOpenChange={(open) => !open && setMarkingDoneId(null)}>
                  <DialogTrigger asChild>
                    <Button 
                      className="w-full mt-2 bg-teal-50 text-teal-700 hover:bg-teal-100 border-teal-200" 
                      variant="outline"
                      onClick={() => setMarkingDoneId(work.id)}
                    >
                      <CheckCircle2 className="w-4 h-4 mr-2" /> Mark as Done
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Complete: {work.partyName}</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label>Completion Remark (Required)</Label>
                        <Input 
                          placeholder="What was done? (e.g., Replaced cable)" 
                          value={remark}
                          onChange={(e) => setRemark(e.target.value)}
                        />
                      </div>
                      <Button onClick={() => handleMarkDone(work.id)} className="w-full bg-teal-600 hover:bg-teal-700">
                        Confirm Done
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </Card>
          ))}
          {myPendingWorks.length === 0 && (
            <div className="text-center py-12 text-muted-foreground flex flex-col items-center">
              <CheckCircle2 className="w-12 h-12 mb-2 text-teal-100" />
              <p>All caught up! No pending work.</p>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="requests" className="space-y-4">
          {myRequests.map(work => (
             <Card key={work.id} className="opacity-75 bg-muted/30">
              <div className="p-4">
                <div className="flex justify-between items-center mb-2">
                   <Badge variant="secondary">Pending Approval</Badge>
                   <span className="text-xs text-muted-foreground">{format(new Date(work.date), "dd MMM yyyy")}</span>
                </div>
                <h3 className="font-semibold">{work.partyName}</h3>
                <p className="text-sm text-muted-foreground">{work.workName}</p>
              </div>
            </Card>
          ))}
           {myRequests.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">No pending requests.</div>
          )}
        </TabsContent>

        <TabsContent value="done" className="space-y-4">
           <Card className="p-4 mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search history (Party or Date)..." 
                className="pl-9"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </Card>
           {filteredDone.map(work => (
             <Card key={work.id} className="bg-muted/10">
              <div className="p-4">
                <div className="flex justify-between items-center mb-2">
                   <Badge variant="outline" className="border-green-200 text-green-700 bg-green-50">Completed</Badge>
                   <span className="text-xs text-muted-foreground">{format(new Date(work.date), "dd/MM/yy")}</span>
                </div>
                <h3 className="font-medium text-muted-foreground line-through">{work.partyName}</h3>
                <p className="text-sm text-muted-foreground/80">{work.workName}</p>
                <div className="mt-2 text-xs italic text-muted-foreground bg-muted p-2 rounded">
                  " {work.remark} "
                </div>
              </div>
            </Card>
          ))}
          {filteredDone.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">No matching history found.</div>
          )}
        </TabsContent>
      </Tabs>
    </LayoutShell>
  );
}
