import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { User, Lock, KeyRound, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function AuthPage() {
  const [, setLocation] = useLocation();
  const login = useStore((state) => state.login);
  const initializeData = useStore((state) => state.initializeData);
  const currentUser = useStore((state) => state.currentUser);
  const { toast } = useToast();

  const [adminUsername, setAdminUsername] = useState("");
  const [adminPassword, setAdminPassword] = useState("");
  const [staffMobile, setStaffMobile] = useState("");
  const [staffPassword, setStaffPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    initializeData();
  }, [initializeData]);

  useEffect(() => {
    if (currentUser) {
      if (currentUser.role === 'admin') {
        setLocation("/admin");
      } else {
        setLocation("/staff");
      }
    }
  }, [currentUser, setLocation]);

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    const success = await login(adminUsername, adminPassword);
    
    if (success) {
      toast({
        title: "Welcome Administrator",
        description: "Logged in successfully.",
      });
      setLocation("/admin");
    } else {
      toast({
        variant: "destructive",
        title: "Login Failed",
        description: "Invalid admin credentials.",
      });
    }
    setIsLoading(false);
  };

  const handleStaffLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    const success = await login(staffMobile, staffPassword);
    
    if (success) {
      toast({
        title: "Welcome",
        description: "Logged in successfully.",
      });
      setLocation("/staff");
    } else {
      toast({
        variant: "destructive",
        title: "Login Failed",
        description: "Staff not found or invalid credentials.",
      });
    }
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted/40 p-4">
      <div className="w-full max-w-md space-y-8 animate-in fade-in zoom-in duration-500">
        <div className="text-center space-y-2">
          <div className="flex justify-center mb-6">
            <img 
              src="/mital.png" 
              alt="MITAL INFOSYS" 
              className="h-24 object-contain animate-in slide-in-from-top duration-700"
            />
          </div>
          <h1 className="text-3xl font-bold font-heading tracking-tight">MITALINFOSYS_SURAT</h1>
          <div className="text-sm text-muted-foreground font-medium space-y-1 mt-2">
            <p>J 116 JAPAN MARKET NR BELGIUM SQ RING ROAD SURAT</p>
            <p>MO. 9725118401 | 9375118401</p>
          </div>
        </div>

        <Tabs defaultValue="admin" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-4">
            <TabsTrigger value="admin" data-testid="tab-admin">Admin</TabsTrigger>
            <TabsTrigger value="staff" data-testid="tab-staff">Staff</TabsTrigger>
          </TabsList>
          
          <TabsContent value="admin">
            <Card className="border-t-4 border-t-primary shadow-lg">
              <CardHeader>
                <CardTitle>Admin Access</CardTitle>
                <CardDescription>Enter your credentials to manage works.</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleAdminLogin} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="admin-user">Username</Label>
                    <div className="relative">
                      <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input 
                        id="admin-user" 
                        data-testid="input-admin-username"
                        placeholder="admin" 
                        className="pl-9"
                        value={adminUsername}
                        onChange={(e) => setAdminUsername(e.target.value)}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="admin-pass">Password</Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input 
                        id="admin-pass" 
                        data-testid="input-admin-password"
                        type="password" 
                        placeholder="•••••" 
                        className="pl-9"
                        value={adminPassword}
                        onChange={(e) => setAdminPassword(e.target.value)}
                      />
                    </div>
                  </div>
                  <Button type="submit" data-testid="button-admin-login" className="w-full font-semibold" disabled={isLoading}>
                    {isLoading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                    Login as Admin
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="staff">
            <Card className="border-t-4 border-t-teal-600 shadow-lg">
              <CardHeader>
                <CardTitle>Staff Access</CardTitle>
                <CardDescription>Use your registered mobile number.</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleStaffLogin} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="staff-mobile">Mobile Number</Label>
                    <div className="relative">
                      <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input 
                        id="staff-mobile" 
                        data-testid="input-staff-mobile"
                        placeholder="9876543210" 
                        className="pl-9"
                        value={staffMobile}
                        onChange={(e) => setStaffMobile(e.target.value)}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="staff-pass">Password</Label>
                    <div className="relative">
                      <KeyRound className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input 
                        id="staff-pass" 
                        data-testid="input-staff-password"
                        type="password" 
                        placeholder="•••••" 
                        className="pl-9"
                        value={staffPassword}
                        onChange={(e) => setStaffPassword(e.target.value)}
                      />
                    </div>
                  </div>
                  <Button type="submit" data-testid="button-staff-login" className="w-full bg-teal-600 hover:bg-teal-700 font-semibold" disabled={isLoading}>
                    {isLoading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                    Login as Staff
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
        
        <div className="text-center text-[10px] text-muted-foreground/20 mt-8 select-none">
        </div>
      </div>
    </div>
  );
}
