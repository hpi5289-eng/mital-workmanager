import { useState, useEffect } from "react";
import { LayoutShell } from "@/components/layout-shell";
import { useStore, type Work, type User } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Plus, Search, CheckCircle2, AlertCircle, Clock, Users, Briefcase, Phone, BookUser, Keyboard, LogOut, KeyRound } from "lucide-react";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";

export default function AdminDashboard() {
  const { works, users, addWork, updateWork, addUser, updateUser, deleteUser, currentUser, fetchUsers, fetchWorks } = useStore();
  const { toast } = useToast();
  
  useEffect(() => {
    fetchUsers();
    fetchWorks();
  }, [fetchUsers, fetchWorks]);
  
  // Local state for forms
  const [newWork, setNewWork] = useState({
    partyName: "",
    workName: "",
    workType: "BASIC" as const,
    assignedToId: "",
  });

  const [newStaff, setNewStaff] = useState({
    name: "",
    username: "",
    password: "", 
  });
  
  const [remark, setRemark] = useState("");
  const [markingDoneId, setMarkingDoneId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [editingStaffId, setEditingStaffId] = useState<string | null>(null);
  const [newPassword, setNewPassword] = useState("");

  const pendingWorks = works.filter(w => w.status === 'pending');
  const approvalWorks = works.filter(w => w.status === 'approval_pending');
  const doneWorks = works.filter(w => w.status === 'done');
  const staffMembers = users.filter(u => u.role === 'staff');

  const filteredHistory = doneWorks.filter(w => {
    const searchLower = searchQuery.toLowerCase();
    const matchesParty = w.partyName.toLowerCase().includes(searchLower);
    const matchesDate = format(new Date(w.date), "dd/MM/yy").includes(searchLower);
    return matchesParty || matchesDate;
  });

  // Mock data for call logs and contacts
  const mockCallLogs = [
    { name: "Rahul Sharma", number: "9876543210", time: "10:30 AM" },
    { name: "Unknown", number: "9123456789", time: "09:15 AM" },
    { name: "Amit Patel", number: "9988776655", time: "Yesterday" },
  ];

  const mockContacts = [
    { name: "Suresh Mehra", number: "8877665544" },
    { name: "Vikram Singh", number: "7766554433" },
    { name: "Deepak Jha", number: "6655443322" },
  ];

  const handleCreateWork = async () => {
    if (!newWork.partyName || !newWork.workName) {
      toast({ variant: "destructive", title: "Missing fields" });
      return;
    }

    await addWork({
      ...newWork,
      date: new Date().toISOString(),
      status: 'pending',
      createdBy: currentUser?.id || 'admin',
    });
    
    setNewWork({ partyName: "", workName: "", workType: "BASIC", assignedToId: "" });
    toast({ title: "Work Assigned Successfully" });
  };

  const handleCreateStaff = async () => {
    if (!newStaff.name || !newStaff.username) return;
    await addUser({
      ...newStaff,
      role: 'staff',
    });
    setNewStaff({ name: "", username: "", password: "" });
    toast({ title: "Staff Member Added" });
  };

  const handleUpdatePassword = async () => {
    if (!editingStaffId || !newPassword) return;
    await updateUser(editingStaffId, { password: newPassword });
    setEditingStaffId(null);
    setNewPassword("");
    toast({ title: "Password Updated", description: "Staff password changed successfully." });
  };

  const handleForceLogout = (staffId: string) => {
    toast({ title: "User Logged Out", description: "Staff member has been logged out of all devices." });
  };

  const handleApproveWork = async (id: string) => {
    await updateWork(id, { status: 'pending' });
    toast({ title: "Work Approved" });
  };

  const handleMarkDone = async (id: string) => {
    if (!remark) {
      toast({ variant: "destructive", title: "Remark is required" });
      return;
    }
    await updateWork(id, { status: 'done', remark });
    setMarkingDoneId(null);
    setRemark("");
    toast({ title: "Work Marked as Done" });
  };

  const selectParty = (name: string, number?: string) => {
    setNewWork({ ...newWork, partyName: number ? `${name} (${number})` : name });
    toast({ title: "Party Selected", description: name });
  };

  return (
    <LayoutShell title="MITAL_INFOSYS_ADMIN_PANEL">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Card className="bg-orange-50 dark:bg-orange-950/20 border-orange-200 dark:border-orange-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-orange-800 dark:text-orange-300">Pending Works</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{pendingWorks.length}</div>
          </CardContent>
        </Card>
        <Card className="bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-blue-800 dark:text-blue-300">Approval Requests</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{approvalWorks.length}</div>
          </CardContent>
        </Card>
        <Card className="bg-green-50 dark:bg-green-950/20 border-green-200 dark:border-green-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-green-800 dark:text-green-300">Completed Works</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{doneWorks.length}</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="pending" className="w-full">
        <TabsList className="mb-4 w-full md:w-auto overflow-x-auto flex-nowrap">
          <TabsTrigger value="pending" className="flex gap-2">
            <Clock className="w-4 h-4" /> Pending
          </TabsTrigger>
          <TabsTrigger value="approval" className="flex gap-2 relative">
            <AlertCircle className="w-4 h-4" /> Approvals
            {approvalWorks.length > 0 && (
              <span className="ml-1 w-2 h-2 rounded-full bg-red-500 absolute top-2 right-2 animate-pulse" />
            )}
          </TabsTrigger>
          <TabsTrigger value="done" className="flex gap-2">
            <CheckCircle2 className="w-4 h-4" /> History
          </TabsTrigger>
          <TabsTrigger value="staff" className="flex gap-2">
            <Users className="w-4 h-4" /> Staff
          </TabsTrigger>
        </TabsList>

        <div className="mb-6 flex justify-end">
           <Dialog>
            <DialogTrigger asChild>
              <Button className="gap-2 shadow-lg hover:shadow-xl transition-all">
                <Plus className="w-4 h-4" /> New Work Assignment
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Assign New Work</DialogTitle>
                <DialogDescription>Assign tasks to staff. Date is auto-set to today.</DialogDescription>
              </DialogHeader>
              <div className="space-y-6 py-4">
                <div className="space-y-4">
                  <Label className="text-base font-bold">Select Party Source</Label>
                  <Tabs defaultValue="manual" className="w-full">
                    <TabsList className="grid w-full grid-cols-3">
                      <TabsTrigger value="manual" className="gap-2">
                        <Keyboard className="w-4 h-4" /> Manual
                      </TabsTrigger>
                      <TabsTrigger value="calllog" className="gap-2">
                        <Phone className="w-4 h-4" /> Call Log
                      </TabsTrigger>
                      <TabsTrigger value="contacts" className="gap-2">
                        <BookUser className="w-4 h-4" /> Contacts
                      </TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="manual" className="pt-4">
                      <div className="space-y-2">
                        <Label>Manual Entry</Label>
                        <Input 
                          placeholder="Type party name or mobile..." 
                          value={newWork.partyName}
                          onChange={(e) => setNewWork({...newWork, partyName: e.target.value})}
                        />
                      </div>
                    </TabsContent>
                    
                    <TabsContent value="calllog" className="pt-4">
                      <div className="grid grid-cols-1 gap-2 max-h-48 overflow-y-auto pr-2 border rounded-md p-2">
                        {mockCallLogs.map((log, i) => (
                          <Button 
                            key={i} 
                            variant="outline" 
                            className="justify-between text-left h-auto py-2 px-3"
                            onClick={() => selectParty(log.name, log.number)}
                          >
                            <div className="flex flex-col">
                              <span className="font-semibold">{log.name}</span>
                              <span className="text-xs text-muted-foreground">{log.number}</span>
                            </div>
                            <span className="text-[10px] bg-muted px-1.5 py-0.5 rounded">{log.time}</span>
                          </Button>
                        ))}
                      </div>
                    </TabsContent>
                    
                    <TabsContent value="contacts" className="pt-4">
                      <div className="grid grid-cols-1 gap-2 max-h-48 overflow-y-auto pr-2 border rounded-md p-2">
                        {mockContacts.map((contact, i) => (
                          <Button 
                            key={i} 
                            variant="outline" 
                            className="justify-between text-left h-auto py-2 px-3"
                            onClick={() => selectParty(contact.name, contact.number)}
                          >
                            <div className="flex flex-col">
                              <span className="font-semibold">{contact.name}</span>
                              <span className="text-xs text-muted-foreground">{contact.number}</span>
                            </div>
                            <BookUser className="w-4 h-4 text-muted-foreground opacity-20" />
                          </Button>
                        ))}
                      </div>
                    </TabsContent>
                  </Tabs>
                </div>

                <div className="space-y-2">
                  <Label>Work Description</Label>
                  <Input 
                    placeholder="What needs to be done?" 
                    value={newWork.workName}
                    onChange={(e) => setNewWork({...newWork, workName: e.target.value})}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Work Type</Label>
                    <Select 
                      value={newWork.workType}
                      onValueChange={(val: any) => setNewWork({...newWork, workType: val})}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {['COMPUTER', 'CCTV', 'PAYMENT', 'SERVICE_CENTER', 'BASIC', 'PUR_DEALER'].map(t => (
                          <SelectItem key={t} value={t}>{t}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Assign Staff</Label>
                    <Select 
                      value={newWork.assignedToId}
                      onValueChange={(val) => setNewWork({...newWork, assignedToId: val})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select Staff" />
                      </SelectTrigger>
                      <SelectContent>
                        {staffMembers.map(s => (
                          <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <Button onClick={handleCreateWork} className="w-full font-bold h-12">Assign Work</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <TabsContent value="pending" className="space-y-4">
          {pendingWorks.map(work => (
            <Card key={work.id} className="overflow-hidden border-l-4 border-l-orange-500">
              <div className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">{work.workType}</Badge>
                    <span className="text-xs text-muted-foreground">{format(new Date(work.date), "dd MMM yyyy")}</span>
                  </div>
                  <h3 className="font-semibold text-lg">{work.partyName}</h3>
                  <p className="text-muted-foreground">{work.workName}</p>
                  <div className="flex items-center gap-2 text-sm mt-2">
                    <Users className="w-4 h-4 text-muted-foreground" />
                    <span className="font-medium text-primary">
                      {users.find(u => u.id === work.assignedToId)?.name || "Unassigned"}
                    </span>
                    <Badge variant="outline" className="ml-auto text-[10px] border-orange-200 text-orange-700 bg-orange-50">
                      Waiting for Staff
                    </Badge>
                  </div>
                </div>
                
                <Dialog open={markingDoneId === work.id} onOpenChange={(open) => !open && setMarkingDoneId(null)}>
                  <DialogTrigger asChild>
                    <Button 
                      variant="outline" 
                      className="shrink-0 border-green-200 hover:bg-green-50 hover:text-green-700 dark:hover:bg-green-900/20"
                      onClick={() => setMarkingDoneId(work.id)}
                    >
                      <CheckCircle2 className="w-4 h-4 mr-2" /> Mark Done
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Complete Work</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label>Completion Remark (Required)</Label>
                        <Input 
                          placeholder="What was done?" 
                          value={remark}
                          onChange={(e) => setRemark(e.target.value)}
                        />
                      </div>
                      <Button onClick={() => handleMarkDone(work.id)} className="w-full">
                        Submit Completion
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </Card>
          ))}
          {pendingWorks.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">No pending works.</div>
          )}
        </TabsContent>

        <TabsContent value="approval" className="space-y-4">
          {approvalWorks.map(work => (
            <Card key={work.id} className="border-l-4 border-l-blue-500">
              <div className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                   <div className="flex items-center gap-2 mb-1">
                    <Badge variant="secondary">Request by {users.find(u => u.id === work.createdBy)?.name}</Badge>
                    <span className="text-xs text-muted-foreground ml-2">{format(new Date(work.date), "dd MMM yyyy")}</span>
                  </div>
                  <h3 className="font-semibold">{work.partyName}</h3>
                  <p className="text-sm text-muted-foreground">{work.workName}</p>
                </div>
                <Button onClick={() => handleApproveWork(work.id)} size="sm">
                  Approve Request
                </Button>
              </div>
            </Card>
          ))}
           {approvalWorks.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">No approval requests.</div>
          )}
        </TabsContent>

        <TabsContent value="done" className="space-y-4">
          <Card className="p-4 mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search history by Party Name or Date (dd/mm/yy)..." 
                className="pl-9"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </Card>
          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Party</TableHead>
                  <TableHead>Work</TableHead>
                  <TableHead>Done By</TableHead>
                  <TableHead>Remark</TableHead>
                  <TableHead>Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredHistory.map(work => (
                  <TableRow key={work.id}>
                    <TableCell>{format(new Date(work.date), "dd/MM/yy")}</TableCell>
                    <TableCell className="font-medium">{work.partyName}</TableCell>
                    <TableCell>
                      <div className="flex flex-col">
                        <span>{work.workName}</span>
                        <Badge variant="outline" className="w-fit text-[10px]">{work.workType}</Badge>
                      </div>
                    </TableCell>
                    <TableCell>{users.find(u => u.id === work.assignedToId)?.name || "-"}</TableCell>
                    <TableCell className="text-muted-foreground italic">{work.remark}</TableCell>
                    <TableCell>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="text-orange-600 hover:text-orange-700 hover:bg-orange-50 gap-1"
                        onClick={() => {
                          updateWork(work.id, { status: 'pending', remark: "" });
                          toast({ title: "Work Moved to Pending", description: "Successfully updated history." });
                        }}
                      >
                        <Clock className="w-3.5 h-3.5" /> Move to Pending
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            {filteredHistory.length === 0 && (
              <div className="text-center py-12 text-muted-foreground">No matching history records found.</div>
            )}
          </Card>
        </TabsContent>

        <TabsContent value="staff">
           <div className="grid gap-4">
            <Card className="p-4 bg-muted/50">
               <h3 className="font-semibold mb-4">Add New Staff</h3>
               <div className="flex flex-col md:flex-row gap-4 items-end">
                 <div className="space-y-2 flex-1">
                   <Label>Full Name</Label>
                   <Input value={newStaff.name} onChange={e => setNewStaff({...newStaff, name: e.target.value})} placeholder="Ex. Rahul Kumar" />
                 </div>
                 <div className="space-y-2 flex-1">
                   <Label>Mobile (Username)</Label>
                   <Input value={newStaff.username} onChange={e => setNewStaff({...newStaff, username: e.target.value})} placeholder="98XXXXXXXX" />
                 </div>
                 <div className="space-y-2 flex-1">
                   <Label>Password</Label>
                   <Input type="password" value={newStaff.password} onChange={e => setNewStaff({...newStaff, password: e.target.value})} placeholder="Set password" />
                 </div>
                 <Button onClick={handleCreateStaff}>Add Staff</Button>
               </div>
            </Card>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {staffMembers.map(staff => (
                <Card key={staff.id} className="relative group overflow-hidden">
                  <CardHeader className="flex flex-row items-center gap-4">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
                      {staff.name.charAt(0)}
                    </div>
                    <div>
                      <CardTitle className="text-base">{staff.name}</CardTitle>
                      <CardDescription>{staff.username}</CardDescription>
                    </div>
                  </CardHeader>
                  <CardContent className="flex gap-2">
                    <Dialog open={editingStaffId === staff.id} onOpenChange={(open) => !open && setEditingStaffId(null)}>
                      <DialogTrigger asChild>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="flex-1 gap-1"
                          onClick={() => setEditingStaffId(staff.id)}
                        >
                          <KeyRound className="w-3.5 h-3.5" /> Password
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Change Password: {staff.name}</DialogTitle>
                          <DialogDescription>Enter a new password for this staff member.</DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4 py-4">
                          <div className="space-y-2">
                            <Label>New Password</Label>
                            <Input 
                              type="password" 
                              placeholder="••••••" 
                              value={newPassword}
                              onChange={(e) => setNewPassword(e.target.value)}
                            />
                          </div>
                          <Button onClick={handleUpdatePassword} className="w-full">Update Password</Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                    
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex-1 gap-1 text-destructive hover:bg-destructive/10"
                      onClick={() => handleForceLogout(staff.id)}
                    >
                      <LogOut className="w-3.5 h-3.5" /> Logout
                    </Button>
                  </CardContent>
                  <Button 
                    variant="destructive" 
                    size="icon" 
                    className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={() => deleteUser(staff.id)}
                  >
                    <span className="sr-only">Delete</span>
                    <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg" className="h-4 w-4"><path d="M5.5 1C5.22386 1 5 1.22386 5 1.5C5 1.77614 5.22386 2 5.5 2H9.5C9.77614 2 10 1.77614 10 1.5C10 1.22386 9.77614 1 9.5 1H5.5ZM3 3.5C3 3.22386 3.22386 3 3.5 3H11.5C11.7761 3 12 3.22386 12 3.5V13.5C12 13.8314 11.7314 14.1 11.4 14.1L3.6 14.1C3.26863 14.1 3 13.8314 3 13.5V3.5ZM4.5 4V13.1H10.5V4H4.5Z" fill="currentColor" fillRule="evenodd" clipRule="evenodd"></path></svg>
                  </Button>
                </Card>
              ))}
            </div>
           </div>
        </TabsContent>
      </Tabs>
    </LayoutShell>
  );
}
