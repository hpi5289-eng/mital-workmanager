import { useState } from "react";
import { useStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { CheckCircle2, Clock, ShieldCheck, User as UserIcon } from "lucide-react";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

export default function WidgetPage() {
  const { works, updateWork, currentUser } = useStore();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [remark, setRemark] = useState("");
  const [activeId, setActiveId] = useState<string | null>(null);

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-[#F0F2F5] flex flex-col items-center justify-center p-6 text-center">
        <ShieldCheck className="w-12 h-12 text-primary mb-4" />
        <h1 className="text-xl font-bold mb-2">Login Required</h1>
        <Button onClick={() => setLocation("/")}>Go to Login</Button>
      </div>
    );
  }

  const isAdmin = currentUser.role === 'admin';
  
  const pendingWorks = works.filter(w => {
    if (isAdmin) return w.status === 'pending';
    return w.status === 'pending' && w.assignedToId === currentUser.id;
  });

  const handleMarkDone = (id: string) => {
    if (!remark) {
      toast({ variant: "destructive", title: "Remark required" });
      return;
    }
    updateWork(id, { status: 'done', remark });
    setRemark("");
    setActiveId(null);
    toast({ title: "Work Completed" });
  };

  return (
    <div className="min-h-screen bg-[#F0F2F5] dark:bg-zinc-950 p-2 font-sans select-none">
      <div className="max-w-md mx-auto space-y-3">
        {/* Widget Header */}
        <div className="flex items-center justify-between px-2 pt-2">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              {isAdmin ? <ShieldCheck className="w-5 h-5 text-white" /> : <UserIcon className="w-5 h-5 text-white" />}
            </div>
            <h2 className="font-bold text-sm tracking-tight uppercase">
              {isAdmin ? "Admin Widget" : "Staff Widget"}
            </h2>
          </div>
          <Badge variant="secondary" className="text-[10px] px-1.5 h-5 font-bold">
            {pendingWorks.length} PENDING
          </Badge>
        </div>

        {/* Task List */}
        <div className="space-y-2">
          {pendingWorks.map((work) => (
            <Card key={work.id} className="p-3 shadow-sm border-none bg-white dark:bg-zinc-900 overflow-hidden">
              <div className="flex flex-col gap-2">
                <div className="flex justify-between items-start">
                  <div className="space-y-0.5">
                    <h3 className="font-bold text-sm leading-tight text-zinc-900 dark:text-zinc-100">{work.partyName}</h3>
                    <p className="text-[11px] text-muted-foreground line-clamp-2 italic">{work.workName}</p>
                  </div>
                  <Badge variant="outline" className="text-[9px] h-4 px-1 lowercase font-normal border-primary/20">
                    {work.workType}
                  </Badge>
                </div>

                <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {format(new Date(work.date), "dd MMM")}
                  </div>
                  {!isAdmin && <span className="font-medium text-teal-600">Assigned to me</span>}
                </div>

                {activeId === work.id ? (
                  <div className="mt-2 space-y-2 animate-in fade-in slide-in-from-top-1">
                    <Input 
                      placeholder="Type completion remark..." 
                      className="h-8 text-xs bg-muted/50 border-none"
                      value={remark}
                      onChange={(e) => setRemark(e.target.value)}
                      autoFocus
                    />
                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        className="flex-1 h-8 text-[11px]" 
                        onClick={() => {setActiveId(null); setRemark("");}}
                      >
                        Cancel
                      </Button>
                      <Button 
                        size="sm" 
                        className="flex-1 h-8 text-[11px] bg-green-600 hover:bg-green-700" 
                        onClick={() => handleMarkDone(work.id)}
                      >
                        Submit Done
                      </Button>
                    </div>
                  </div>
                ) : (
                  <Button 
                    variant="secondary" 
                    className="w-full h-8 mt-1 text-[11px] font-bold bg-muted hover:bg-muted/80 text-primary"
                    onClick={() => setActiveId(work.id)}
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 mr-1.5" /> Mark Done
                  </Button>
                )}
              </div>
            </Card>
          ))}

          {pendingWorks.length === 0 && (
            <div className="py-10 text-center text-muted-foreground text-xs italic">
              No pending tasks found.
            </div>
          )}
        </div>
        
        <div className="text-[9px] text-center text-muted-foreground pt-4 opacity-50">
          MITAL INFOSYS MOBILE WIDGET VIEW
        </div>
      </div>
    </div>
  );
}
