import { useStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { LogOut } from "lucide-react";
import { useLocation } from "wouter";

interface LayoutShellProps {
  children: React.ReactNode;
  title: string;
}

export function LayoutShell({ children, title }: LayoutShellProps) {
  const logout = useStore((state) => state.logout);
  const [, setLocation] = useLocation();
  const currentUser = useStore((state) => state.currentUser);

  const handleLogout = () => {
    logout();
    setLocation("/");
  };

  return (
    <div className="min-h-screen bg-background flex flex-col font-sans">
      {/* Header */}
      <header className="border-b bg-card sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <img src="/mital.png" alt="Logo" className="h-10 w-auto object-contain" />
              <div className="h-8 w-[1px] bg-border mx-1 hidden sm:block" />
            </div>
            <div>
              <h1 className="font-heading font-bold text-lg leading-tight">{title}</h1>
              {currentUser && (
                <p className="text-xs text-muted-foreground font-medium">
                  Hello, {currentUser.name}
                </p>
              )}
            </div>
          </div>
          
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={handleLogout}
            className="text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors"
            title="Logout"
          >
            <LogOut className="h-5 w-5" />
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 p-4 md:p-6 max-w-7xl mx-auto w-full">
        {children}
      </main>
    </div>
  );
}
